@echo off
echo Membuat shortcut MusicGan di Desktop...
powershell -NoProfile -Command "$ws = New-Object -ComObject WScript.Shell; $desk = [Environment]::GetFolderPath('Desktop'); $s = $ws.CreateShortcut([System.IO.Path]::Combine($desk, 'MusicGan.lnk')); $s.TargetPath = '%~dp0MusicGan.exe'; $s.WorkingDirectory = '%~dp0'; $s.IconLocation = '%~dp0app.ico'; $s.Save(); Write-Host '[OK] Shortcut MusicGan berhasil dibuat di Desktop!'"
pause
